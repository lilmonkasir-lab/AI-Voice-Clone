@echo off
title Chatterbox Turbo Local
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 py -3.11 -m venv .venv
 if errorlevel 1 (echo Python 3.11 required.&pause&exit /b 1)
)
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
where ffmpeg >nul 2>nul
if errorlevel 1 echo WARNING: FFmpeg not found. MP3 export may not work. Install FFmpeg and add it to PATH.
start "" "http://127.0.0.1:7860"
python app.py
pause
