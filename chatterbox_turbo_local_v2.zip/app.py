import os, uuid, traceback
from pathlib import Path
import torch
import torchaudio as ta
from pydub import AudioSegment
from flask import Flask, jsonify, request, send_from_directory
from chatterbox.tts_turbo import ChatterboxTurboTTS

BASE=Path(__file__).resolve().parent
UPLOAD=BASE/"uploads"; OUTPUT=BASE/"outputs"
UPLOAD.mkdir(exist_ok=True); OUTPUT.mkdir(exist_ok=True)
app=Flask(__name__)
MODEL=None
LOCK=__import__("threading").Lock()

def get_model():
    global MODEL
    if MODEL is None:
        device="cuda" if torch.cuda.is_available() else "cpu"
        print(f"Loading Chatterbox Turbo on {device}...")
        MODEL=ChatterboxTurboTTS.from_pretrained(device=device)
        print("Model ready.")
    return MODEL

@app.get("/")
def index(): return send_from_directory(BASE,"index.html")

@app.get("/api/status")
def status():
    return jsonify({"ready":MODEL is not None,"cuda":torch.cuda.is_available(),
                    "gpu":torch.cuda.get_device_name(0) if torch.cuda.is_available() else None})

@app.post("/api/generate")
def generate():
    text=request.form.get("text","").strip()
    ref=request.files.get("reference")
    if not text: return jsonify(error="Enter some text first."),400
    if not ref: return jsonify(error="Choose a reference audio file."),400
    job=uuid.uuid4().hex
    suffix=Path(ref.filename).suffix.lower()
    refpath=UPLOAD/f"{job}{suffix}"; out=OUTPUT/f"chatterbox_{job}.wav"
    ref.save(refpath)
    try:
        with LOCK:
            model=get_model()
            wav=model.generate(text,audio_prompt_path=str(refpath))
            ta.save(str(out),wav,model.sr)
        return jsonify(ok=True,file=f"/outputs/{out.name}")
    except Exception as e:
        traceback.print_exc()
        return jsonify(error=str(e)),500
    finally: refpath.unlink(missing_ok=True)

@app.post("/api/mp3")
def mp3():
    name=Path(request.json.get("file","")).name
    if not name.lower().endswith(".wav"): return jsonify(error="Invalid WAV."),400
    wav=OUTPUT/name
    if not wav.exists(): return jsonify(error="WAV not found."),404
    out=wav.with_suffix(".mp3")
    try:
        AudioSegment.from_wav(str(wav)).export(str(out),format="mp3",bitrate="192k")
        return jsonify(ok=True,file=f"/outputs/{out.name}")
    except Exception as e:
        return jsonify(error=f"MP3 conversion failed: {e}"),500

@app.get("/outputs/<path:name>")
def outputs(name): return send_from_directory(OUTPUT,name,as_attachment=False)

if __name__=="__main__":
    print("Open http://127.0.0.1:7860")
    get_model()
    app.run("127.0.0.1",7860,debug=False)
